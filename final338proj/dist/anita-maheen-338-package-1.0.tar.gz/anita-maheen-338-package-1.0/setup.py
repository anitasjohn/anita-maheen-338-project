from setuptools import setup, find_packages

setup(name='anita-maheen-338-package',
      version='1.0',
      description='a simple library providing various datastructures',
      author='Anita John, Maheen Raza',
      author_email ="anita.john@ucalgary.ca, maheen.raza@ucalgary.ca",
      packages = find_packages(),
      install_requires=[],
      
)